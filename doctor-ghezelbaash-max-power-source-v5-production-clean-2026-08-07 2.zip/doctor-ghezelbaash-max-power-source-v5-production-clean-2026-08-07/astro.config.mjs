import { defineConfig } from 'astro/config';
export default defineConfig({site:'https://www.ghezelbaash.ir',output:'static',trailingSlash:'always',compressHTML:true,build:{format:'directory',inlineStylesheets:'always'},vite:{build:{sourcemap:false}}});
